package models;

import java.util.ArrayList;

public class Actions {
	public static String ACTION_WORD = "Give Compliment";
	public static String ACTION_PHYSICAL = "Give Hug";
	public static String ACTION_TIME = "Spend time together";
	public static String ACTION_GIFT = "Give a gift";
	public static String ACTION_SERVICE = "Help with chores";
	public static String ACTIONS[] = {ACTION_WORD, ACTION_PHYSICAL, ACTION_TIME, ACTION_GIFT, ACTION_SERVICE};
}